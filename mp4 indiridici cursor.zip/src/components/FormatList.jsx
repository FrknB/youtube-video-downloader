const FormatList = ({ formats, onDownload, downloadingFormat, downloadProgress }) => {
  const getQualityBadge = (quality) => {
    if (quality.includes('2160') || quality.includes('4K')) {
      return { label: '4K Ultra HD', color: 'from-purple-600 to-pink-600', glow: 'shadow-purple-500/30' }
    }
    if (quality.includes('1440') || quality.includes('2K')) {
      return { label: '2K QHD', color: 'from-blue-600 to-cyan-600', glow: 'shadow-blue-500/30' }
    }
    if (quality.includes('1080')) {
      return { label: 'Full HD', color: 'from-green-600 to-emerald-600', glow: 'shadow-green-500/30' }
    }
    if (quality.includes('720')) {
      return { label: 'HD', color: 'from-orange-500 to-amber-500', glow: 'shadow-orange-500/30' }
    }
    return { label: 'SD', color: 'from-zinc-500 to-zinc-600', glow: 'shadow-zinc-500/20' }
  }

  const getCodecInfo = (codec) => {
    const codecMap = {
      'h264': { name: 'H.264', desc: 'Yüksek uyumluluk' },
      'h265': { name: 'H.265/HEVC', desc: 'Daha iyi sıkıştırma' },
      'av1': { name: 'AV1', desc: 'En yeni codec' },
      'vp9': { name: 'VP9', desc: 'Google codec' }
    }
    return codecMap[codec?.toLowerCase()] || { name: codec || 'Bilinmiyor', desc: '' }
  }

  const getStatusText = (status) => {
    switch (status) {
      case 'starting': return 'Başlatılıyor...'
      case 'downloading': return 'İndiriliyor, lütfen bekleyin...'
      case 'merging': return 'Birleştiriliyor, lütfen bekleyin...'
      case 'completed': return 'Tamamlandı!'
      default: return 'Hazırlanıyor...'
    }
  }

  const progress = downloadProgress || { percent: 0, speed: '', eta: '', status: '' }

  return (
    <div className="glass-card rounded-3xl p-6 md:p-8 shadow-2xl shadow-black/5 dark:shadow-black/20">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h3 className="text-xl md:text-2xl font-bold text-zinc-900 dark:text-white">
            İndirilebilir Formatlar
          </h3>
          <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">
            Video + Ses birleşik formatlar (H.264 / H.265)
          </p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-xl">
          <svg className="w-5 h-5 text-green-600 dark:text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span className="text-sm font-medium text-green-700 dark:text-green-300">
            {formats.length} format mevcut
          </span>
        </div>
      </div>

      {/* Format Grid */}
      <div className="grid gap-4">
        {formats.map((format, index) => {
          const badge = getQualityBadge(format.quality)
          const codecInfo = getCodecInfo(format.codec)
          const isDownloading = downloadingFormat === format.id

          return (
            <div
              key={format.id}
              className={`relative overflow-hidden rounded-2xl border-2 transition-all duration-300 animate-slide-up ${
                isDownloading
                  ? 'border-red-500 bg-red-50 dark:bg-red-900/10'
                  : 'border-zinc-200 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800/50 hover:border-red-300 dark:hover:border-red-700 hover:bg-white dark:hover:bg-zinc-800'
              }`}
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <div className="relative p-4 md:p-5 flex flex-col md:flex-row md:items-center gap-4">
                {/* Quality Badge */}
                <div className="flex items-center gap-4 flex-1 min-w-0">
                  <div className={`flex-shrink-0 px-4 py-2 rounded-xl bg-gradient-to-r ${badge.color} shadow-lg ${badge.glow}`}>
                    <span className="text-white font-bold text-sm">{badge.label}</span>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-lg text-zinc-900 dark:text-white">
                        {format.quality}
                      </span>
                      <span className="px-2 py-0.5 bg-zinc-200 dark:bg-zinc-700 rounded text-xs font-medium text-zinc-600 dark:text-zinc-300">
                        {format.format.toUpperCase()}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 mt-1 text-sm text-zinc-500 dark:text-zinc-400">
                      <span className="flex items-center gap-1.5">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                        {codecInfo.name}
                      </span>
                      <span className="hidden sm:flex items-center gap-1.5">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M19.114 5.636a9 9 0 010 12.728M16.463 8.288a5.25 5.25 0 010 7.424M6.75 8.25l4.72-4.72a.75.75 0 011.28.53v15.88a.75.75 0 01-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.01 9.01 0 012.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75z" />
                        </svg>
                        {format.audioCodec}
                      </span>
                      <span className="flex items-center gap-1.5">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 6.375c0 2.278-3.694 4.125-8.25 4.125S3.75 8.653 3.75 6.375m16.5 0c0-2.278-3.694-4.125-8.25-4.125S3.75 4.097 3.75 6.375m16.5 0v11.25c0 2.278-3.694 4.125-8.25 4.125s-8.25-1.847-8.25-4.125V6.375m16.5 0v3.75m-16.5-3.75v3.75m16.5 0v3.75C20.25 16.153 16.556 18 12 18s-8.25-1.847-8.25-4.125v-3.75m16.5 0c0 2.278-3.694 4.125-8.25 4.125s-8.25-1.847-8.25-4.125" />
                        </svg>
                        {format.fileSize}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Download Button */}
                <button
                  onClick={() => onDownload(format)}
                  disabled={downloadingFormat !== null}
                  className={`flex-shrink-0 flex items-center justify-center gap-2 px-5 py-3 rounded-xl font-semibold text-sm transition-all duration-300 min-w-[120px] ${
                    isDownloading
                      ? 'bg-red-500 text-white cursor-wait'
                      : downloadingFormat !== null
                      ? 'bg-zinc-200 dark:bg-zinc-700 text-zinc-400 dark:text-zinc-500 cursor-not-allowed'
                      : 'bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 text-white shadow-lg shadow-red-500/25 hover:shadow-red-500/40 hover:scale-105 active:scale-95'
                  }`}
                >
                  {isDownloading ? (
                    <>
                      <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      <span>{progress.percent}%</span>
                    </>
                  ) : (
                    <>
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                      </svg>
                      <span>İndir</span>
                    </>
                  )}
                </button>
              </div>

              {/* Detailed Progress Section */}
              {isDownloading && (
                <div className="px-4 md:px-5 pb-4 md:pb-5">
                  {/* Progress Bar */}
                  <div className="h-3 bg-zinc-200 dark:bg-zinc-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-red-500 via-red-400 to-orange-500 transition-all duration-300 ease-out rounded-full relative"
                      style={{ width: `${progress.percent}%` }}
                    >
                      {/* Animated shine effect */}
                      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer"></div>
                    </div>
                  </div>

                  {/* Progress Details */}
                  <div className="flex flex-wrap items-center justify-between gap-2 mt-3">
                    {/* Status */}
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${progress.status === 'merging' ? 'bg-orange-500' : 'bg-green-500'} animate-pulse`}></span>
                      <span className="text-sm font-medium text-zinc-700 dark:text-zinc-300">
                        {getStatusText(progress.status)}
                      </span>
                    </div>

                    {/* Stats */}
                    <div className="flex items-center gap-4 text-sm text-zinc-500 dark:text-zinc-400">
                      {progress.speed && (
                        <div className="flex items-center gap-1.5">
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" />
                          </svg>
                          <span className="font-medium text-green-600 dark:text-green-400">{progress.speed}</span>
                        </div>
                      )}
                      {progress.eta && (
                        <div className="flex items-center gap-1.5">
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          <span>Kalan: {progress.eta}</span>
                        </div>
                      )}
                      {progress.totalSize && (
                        <div className="flex items-center gap-1.5">
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 6.375c0 2.278-3.694 4.125-8.25 4.125S3.75 8.653 3.75 6.375m16.5 0c0-2.278-3.694-4.125-8.25-4.125S3.75 4.097 3.75 6.375m16.5 0v11.25c0 2.278-3.694 4.125-8.25 4.125s-8.25-1.847-8.25-4.125V6.375m16.5 0v3.75m-16.5-3.75v3.75m16.5 0v3.75C20.25 16.153 16.556 18 12 18s-8.25-1.847-8.25-4.125v-3.75m16.5 0c0 2.278-3.694 4.125-8.25 4.125s-8.25-1.847-8.25-4.125" />
                          </svg>
                          <span>{progress.totalSize}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}

export default FormatList
