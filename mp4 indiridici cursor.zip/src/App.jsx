import { useState, useEffect } from 'react'
import Header from './components/Header'
import URLInput from './components/URLInput'
import VideoInfo from './components/VideoInfo'
import FormatList from './components/FormatList'
import Toast from './components/Toast'
import Footer from './components/Footer'
import { mockVideoData, analyzeVideo, downloadFormat } from './utils/mockApi'

function App() {
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('darkMode') === 'true' || 
        window.matchMedia('(prefers-color-scheme: dark)').matches
    }
    return false
  })
  
  const [url, setUrl] = useState('')
  const [videoData, setVideoData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [downloadingFormat, setDownloadingFormat] = useState(null)
  const [downloadProgress, setDownloadProgress] = useState({ percent: 0, speed: '', eta: '', status: '' })
  const [error, setError] = useState(null)
  const [toast, setToast] = useState(null)

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
    localStorage.setItem('darkMode', darkMode)
  }, [darkMode])

  const showToast = (message, type = 'info') => {
    setToast({ message, type })
  }

  const handleAnalyze = async () => {
    if (!url.trim()) {
      setError('Lütfen geçerli bir YouTube URL\'si girin')
      showToast('Lütfen geçerli bir YouTube URL\'si girin', 'error')
      return
    }

    // Basic YouTube URL validation
    const youtubeRegex = /^(https?:\/\/)?(www\.)?(youtube\.com\/(watch\?v=|embed\/|v\/)|youtu\.be\/)[\w-]+/
    if (!youtubeRegex.test(url)) {
      setError('Geçersiz YouTube URL\'si. Lütfen doğru bir link girin.')
      showToast('Geçersiz YouTube URL\'si', 'error')
      return
    }

    setLoading(true)
    setError(null)
    setVideoData(null)

    try {
      const data = await analyzeVideo(url)
      // Store original URL for download
      data.originalUrl = url
      setVideoData(data)
      showToast('Video başarıyla analiz edildi!', 'success')
    } catch (err) {
      setError(err.message)
      showToast(err.message, 'error')
    } finally {
      setLoading(false)
    }
  }

  const handleDownload = async (format) => {
    setDownloadingFormat(format.id)
    setDownloadProgress({ percent: 0, speed: '', eta: '', status: 'starting' })
    showToast(`${format.quality} indiriliyor...`, 'info')

    try {
      await downloadFormat(format, (progress) => {
        setDownloadProgress(progress)
      }, videoData)
      showToast(`${format.quality} başarıyla indirildi!`, 'success')
    } catch (err) {
      showToast(`İndirme hatası: ${err.message}`, 'error')
    } finally {
      setDownloadingFormat(null)
      setDownloadProgress({ percent: 0, speed: '', eta: '', status: '' })
    }
  }

  const handleClear = () => {
    setUrl('')
    setVideoData(null)
    setError(null)
  }

  return (
    <div className={`min-h-screen transition-colors duration-500 ${darkMode ? 'bg-mesh-dark' : 'bg-mesh-light'}`}>
      <div className="min-h-screen flex flex-col">
        <Header darkMode={darkMode} setDarkMode={setDarkMode} />
        
        <main className="flex-1 container mx-auto px-4 py-8 md:py-12">
          <div className="max-w-4xl mx-auto space-y-8">
            {/* Hero Section */}
            <div className="text-center space-y-4 animate-fade-in">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold bg-gradient-to-r from-red-600 via-red-500 to-orange-500 bg-clip-text text-transparent">
                YouTube Video İndirici
              </h1>
              <p className="text-zinc-600 dark:text-zinc-400 text-lg md:text-xl max-w-2xl mx-auto">
                Yüksek çözünürlüklü videoları <span className="font-semibold text-red-500">video + ses birleşik</span> olarak indirin
              </p>
            </div>

            {/* URL Input Card */}
            <div className="glass-card rounded-3xl p-6 md:p-8 shadow-2xl shadow-black/5 dark:shadow-black/20 animate-slide-up">
              <URLInput
                url={url}
                setUrl={setUrl}
                onAnalyze={handleAnalyze}
                onClear={handleClear}
                loading={loading}
                hasVideo={!!videoData}
              />
              
              {error && (
                <div className="mt-4 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl animate-scale-in">
                  <div className="flex items-center gap-3">
                    <div className="flex-shrink-0">
                      <svg className="w-5 h-5 text-red-500" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <p className="text-red-700 dark:text-red-300 text-sm font-medium">{error}</p>
                  </div>
                </div>
              )}
            </div>

            {/* Loading State */}
            {loading && (
              <div className="glass-card rounded-3xl p-8 md:p-12 shadow-2xl shadow-black/5 dark:shadow-black/20 animate-fade-in">
                <div className="flex flex-col items-center justify-center space-y-6">
                  <div className="relative">
                    <div className="w-20 h-20 border-4 border-zinc-200 dark:border-zinc-700 rounded-full"></div>
                    <div className="absolute top-0 left-0 w-20 h-20 border-4 border-red-500 rounded-full border-t-transparent animate-spin"></div>
                  </div>
                  <div className="text-center space-y-2">
                    <p className="text-xl font-semibold text-zinc-800 dark:text-zinc-200">Video Analiz Ediliyor...</p>
                    <p className="text-zinc-500 dark:text-zinc-400">Lütfen bekleyin, format bilgileri alınıyor</p>
                  </div>
                </div>
              </div>
            )}

            {/* Video Info & Formats */}
            {videoData && !loading && (
              <div className="space-y-6 animate-slide-up">
                <VideoInfo video={videoData} />
              
                <FormatList
                  formats={videoData.formats}
                  onDownload={handleDownload}
                  downloadingFormat={downloadingFormat}
                  downloadProgress={downloadProgress}
                />
              </div>
            )}
          </div>
        </main>

        <Footer />
      </div>

      {/* Toast Notification */}
      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  )
}

export default App