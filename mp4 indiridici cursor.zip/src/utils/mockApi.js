// API Base URL - production'da aynı origin kullanılır
const API_BASE = import.meta.env.PROD 
  ? '/api' 
  : 'http://localhost:3001/api'

// Extract video ID from URL
export const extractVideoId = (url) => {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/v\/)([^&\n?#]+)/,
    /^([a-zA-Z0-9_-]{11})$/
  ]

  for (const pattern of patterns) {
    const match = url.match(pattern)
    if (match) return match[1]
  }
  return null
}

// Analyze video using backend API
export const analyzeVideo = async (url) => {
  try {
    const response = await fetch(`${API_BASE}/analyze`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ url })
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Video analiz edilemedi')
    }

    return await response.json()
  } catch (error) {
    // If backend is not available, throw helpful error
    if (error.message.includes('fetch')) {
      throw new Error('Backend sunucusu çalışmıyor. Lütfen server klasöründe "npm start" komutunu çalıştırın.')
    }
    throw error
  }
}

// Start download and track progress with SSE
export const downloadFormat = async (format, onProgress, videoInfo = null) => {
  // Generate filename
  const videoTitle = videoInfo?.title || 'video'
  const safeTitle = videoTitle.replace(/[^a-zA-Z0-9\s-]/g, '').replace(/\s+/g, '_').substring(0, 50)
  const qualityTag = format.quality.replace(/[^a-zA-Z0-9]/g, '')
  const filename = `${safeTitle}_${qualityTag}.mp4`

  try {
    // Step 1: Start download
    const startResponse = await fetch(`${API_BASE}/download/start`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        url: videoInfo?.originalUrl || '',
        formatId: format.id,
        quality: qualityTag,
        filename
      })
    })

    if (!startResponse.ok) {
      const error = await startResponse.json()
      throw new Error(error.error || 'İndirme başlatılamadı')
    }

    const { downloadId } = await startResponse.json()

    // Step 2: Track progress with SSE
    return new Promise((resolve, reject) => {
      const eventSource = new EventSource(`${API_BASE}/download/progress/${downloadId}`)
      
      eventSource.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data)
          
          if (data.status === 'not_found') {
            eventSource.close()
            reject(new Error('İndirme bulunamadı'))
            return
          }

          if (data.status === 'error') {
            eventSource.close()
            reject(new Error(data.error || 'İndirme hatası'))
            return
          }

          // Update progress with detailed info
          onProgress({
            percent: Math.round(data.progress || 0),
            speed: data.speed || '',
            eta: data.eta || '',
            status: data.status || 'downloading',
            totalSize: data.totalSize || ''
          })

          if (data.status === 'completed') {
            eventSource.close()
            
            // Trigger file download
            const fileUrl = `${API_BASE}/download/file/${downloadId}`
            triggerFileDownload(fileUrl, filename)
            
            resolve({
              success: true,
              message: `${format.quality} başarıyla indirildi!`
            })
          }
        } catch (e) {
          console.error('Progress parse error:', e)
        }
      }

      eventSource.onerror = (error) => {
        console.error('SSE error:', error)
        eventSource.close()
        reject(new Error('Bağlantı hatası'))
      }
    })

  } catch (error) {
    throw error
  }
}

// Trigger file download
const triggerFileDownload = (url, filename) => {
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  link.style.display = 'none'
  document.body.appendChild(link)
  link.click()
  setTimeout(() => {
    document.body.removeChild(link)
  }, 100)
}

// Validate YouTube URL
export const isValidYouTubeUrl = (url) => {
  if (!url || typeof url !== 'string') return false
  
  const patterns = [
    /^(https?:\/\/)?(www\.)?youtube\.com\/watch\?v=[\w-]+/,
    /^(https?:\/\/)?(www\.)?youtu\.be\/[\w-]+/,
    /^(https?:\/\/)?(www\.)?youtube\.com\/embed\/[\w-]+/,
    /^(https?:\/\/)?(www\.)?youtube\.com\/v\/[\w-]+/
  ]

  return patterns.some(pattern => pattern.test(url.trim()))
}

// Get video thumbnail URL
export const getThumbnailUrl = (videoId, quality = 'maxresdefault') => {
  const qualities = ['maxresdefault', 'sddefault', 'hqdefault', 'mqdefault', 'default']
  const q = qualities.includes(quality) ? quality : 'maxresdefault'
  return `https://img.youtube.com/vi/${videoId}/${q}.jpg`
}

// Format duration for display
export const formatDuration = (seconds) => {
  const hrs = Math.floor(seconds / 3600)
  const mins = Math.floor((seconds % 3600) / 60)
  const secs = seconds % 60

  if (hrs > 0) {
    return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }
  return `${mins}:${secs.toString().padStart(2, '0')}`
}

// Format view count for display
export const formatViewCount = (views) => {
  if (views >= 1000000000) {
    return `${(views / 1000000000).toFixed(1)}B`
  }
  if (views >= 1000000) {
    return `${(views / 1000000).toFixed(1)}M`
  }
  if (views >= 1000) {
    return `${(views / 1000).toFixed(1)}K`
  }
  return views.toString()
}

// Mock data for fallback (when backend is not available)
export const mockVideoData = {
  id: 'dQw4w9WgXcQ',
  title: 'Rick Astley - Never Gonna Give You Up (Official Music Video)',
  thumbnail: 'https://img.youtube.com/vi/dQw4w9WgXcQ/maxresdefault.jpg',
  channel: 'Rick Astley',
  subscribers: '3.85M',
  views: 1500000000,
  likes: 16000000,
  duration: 213,
  uploadDate: '25 Ekim 2009',
  formats: []
}
