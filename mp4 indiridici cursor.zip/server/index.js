import express from 'express'
import cors from 'cors'
import { spawn, exec } from 'child_process'
import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'
import { createReadStream, statSync } from 'fs'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const app = express()
const PORT = process.env.PORT || 3001
const isProduction = process.env.NODE_ENV === 'production'

app.use(cors())
app.use(express.json())

// Serve static files in production
const distPath = path.join(__dirname, '..', 'dist')
console.log(`📁 Static files path: ${distPath}`)
console.log(`📁 Path exists: ${fs.existsSync(distPath)}`)

if (fs.existsSync(distPath)) {
  app.use(express.static(distPath, {
    maxAge: isProduction ? '1d' : 0,
    etag: true
  }))
  console.log('✅ Static files configured')
} else {
  console.warn('⚠️ Dist folder not found. Run "npm run build" first.')
}

// Temp directory for downloads
const TEMP_DIR = path.join(__dirname, 'temp')
if (!fs.existsSync(TEMP_DIR)) {
  fs.mkdirSync(TEMP_DIR, { recursive: true })
}

// Clean old temp files on startup
cleanTempFiles()

// Active downloads tracking
const activeDownloads = new Map()

// Get video info
app.post('/api/analyze', async (req, res) => {
  const { url } = req.body

  if (!url) {
    return res.status(400).json({ error: 'URL gerekli' })
  }

  try {
    const info = await getVideoInfo(url)
    res.json(info)
  } catch (error) {
    console.error('Analyze error:', error)
    res.status(500).json({ error: error.message || 'Video analiz edilemedi' })
  }
})

// Start download and return download ID
app.post('/api/download/start', async (req, res) => {
  const { url, formatId, quality, filename } = req.body

  if (!url) {
    return res.status(400).json({ error: 'URL gerekli' })
  }

  const downloadId = Date.now().toString(36) + Math.random().toString(36).substr(2)
  const safeFilename = filename 
    ? filename.replace(/[^a-zA-Z0-9_\-\.]/g, '_') 
    : `video_${quality || 'download'}.mp4`
  
  const outputPath = path.join(TEMP_DIR, `${downloadId}_${safeFilename}`)

  // Store download info
  activeDownloads.set(downloadId, {
    status: 'starting',
    progress: 0,
    speed: '',
    eta: '',
    filename: safeFilename,
    outputPath,
    error: null
  })

  // Start download in background
  startDownload(downloadId, url, formatId, outputPath)

  res.json({ downloadId, filename: safeFilename })
})

// Get download progress (SSE - Server Sent Events)
app.get('/api/download/progress/:downloadId', (req, res) => {
  const { downloadId } = req.params

  res.setHeader('Content-Type', 'text/event-stream')
  res.setHeader('Cache-Control', 'no-cache')
  res.setHeader('Connection', 'keep-alive')
  res.setHeader('Access-Control-Allow-Origin', '*')

  const sendProgress = () => {
    const download = activeDownloads.get(downloadId)
    if (download) {
      res.write(`data: ${JSON.stringify(download)}\n\n`)
      
      if (download.status === 'completed' || download.status === 'error') {
        res.end()
        return
      }
    } else {
      res.write(`data: ${JSON.stringify({ status: 'not_found' })}\n\n`)
      res.end()
      return
    }
  }

  // Send initial progress
  sendProgress()

  // Send progress updates every 500ms
  const interval = setInterval(() => {
    const download = activeDownloads.get(downloadId)
    if (!download || download.status === 'completed' || download.status === 'error') {
      clearInterval(interval)
      sendProgress()
      return
    }
    sendProgress()
  }, 500)

  // Cleanup on client disconnect
  req.on('close', () => {
    clearInterval(interval)
  })
})

// Get completed file
app.get('/api/download/file/:downloadId', (req, res) => {
  const { downloadId } = req.params
  const download = activeDownloads.get(downloadId)

  if (!download) {
    return res.status(404).json({ error: 'İndirme bulunamadı' })
  }

  if (download.status !== 'completed') {
    return res.status(400).json({ error: 'İndirme henüz tamamlanmadı' })
  }

  if (!fs.existsSync(download.outputPath)) {
    return res.status(404).json({ error: 'Dosya bulunamadı' })
  }

  const stat = statSync(download.outputPath)
  
  res.setHeader('Content-Type', 'video/mp4')
  res.setHeader('Content-Length', stat.size)
  res.setHeader('Content-Disposition', `attachment; filename="${download.filename}"`)

  const stream = createReadStream(download.outputPath)
  stream.pipe(res)

  stream.on('end', () => {
    // Clean up after download
    setTimeout(() => {
      try {
        fs.unlinkSync(download.outputPath)
        activeDownloads.delete(downloadId)
      } catch (e) {}
    }, 5000)
  })
})

// Start the actual download process
function startDownload(downloadId, url, formatId, outputPath) {
  const download = activeDownloads.get(downloadId)
  if (!download) return

  download.status = 'downloading'

  // Build yt-dlp command with maximum speed options
  const args = [
    '-f', formatId || 'bestvideo[vcodec^=avc]+bestaudio[ext=m4a]/bestvideo[vcodec^=hev]+bestaudio[ext=m4a]/best[ext=mp4]/best',
    '--merge-output-format', 'mp4',
    '-o', outputPath,
    '--no-playlist',
    '--no-warnings',
    '--no-check-certificates',
    '--newline', // Progress on new lines for parsing
    // Speed optimization
    '-N', '16', // 16 concurrent connections
    '--buffer-size', '512K',
    '--retries', '10',
    '--fragment-retries', '10',
    // External downloader for maximum speed
    '--downloader', 'aria2c',
    '--downloader-args', 'aria2c:-x 16 -s 16 -k 1M',
    url
  ]

  console.log(`Starting download: ${downloadId}`)
  const ytdlp = spawn('yt-dlp', args)

  ytdlp.stdout.on('data', (data) => {
    const output = data.toString()
    parseProgress(downloadId, output)
  })

  ytdlp.stderr.on('data', (data) => {
    const output = data.toString()
    console.log(`yt-dlp stderr: ${output}`)
    // Also parse stderr as some progress info goes there
    parseProgress(downloadId, output)
  })

  ytdlp.on('error', (error) => {
    console.error('yt-dlp error:', error)
    const download = activeDownloads.get(downloadId)
    if (download) {
      // If aria2c not found, retry without external downloader
      if (error.message.includes('aria2c') || error.code === 'ENOENT') {
        startDownloadWithoutAria(downloadId, url, formatId, outputPath)
        return
      }
      download.status = 'error'
      download.error = error.message
    }
  })

  ytdlp.on('close', (code) => {
    const download = activeDownloads.get(downloadId)
    if (download && download.status !== 'error') {
      if (code === 0 && fs.existsSync(outputPath)) {
        download.status = 'completed'
        download.progress = 100
        console.log(`Download completed: ${downloadId}`)
      } else {
        download.status = 'error'
        download.error = `İndirme başarısız (kod: ${code})`
      }
    }
  })
}

// Fallback download without aria2c
function startDownloadWithoutAria(downloadId, url, formatId, outputPath) {
  const download = activeDownloads.get(downloadId)
  if (!download) return

  console.log(`Retrying without aria2c: ${downloadId}`)
  download.status = 'downloading'
  download.progress = 0

  const args = [
    '-f', formatId || 'bestvideo[vcodec^=avc]+bestaudio[ext=m4a]/bestvideo[vcodec^=hev]+bestaudio[ext=m4a]/best[ext=mp4]/best',
    '--merge-output-format', 'mp4',
    '-o', outputPath,
    '--no-playlist',
    '--no-warnings',
    '--no-check-certificates',
    '--newline',
    '-N', '8',
    '--buffer-size', '512K',
    url
  ]

  const ytdlp = spawn('yt-dlp', args)

  ytdlp.stdout.on('data', (data) => {
    parseProgress(downloadId, data.toString())
  })

  ytdlp.stderr.on('data', (data) => {
    parseProgress(downloadId, data.toString())
  })

  ytdlp.on('error', (error) => {
    const download = activeDownloads.get(downloadId)
    if (download) {
      download.status = 'error'
      download.error = error.message
    }
  })

  ytdlp.on('close', (code) => {
    const download = activeDownloads.get(downloadId)
    if (download && download.status !== 'error') {
      if (code === 0 && fs.existsSync(outputPath)) {
        download.status = 'completed'
        download.progress = 100
      } else {
        download.status = 'error'
        download.error = `İndirme başarısız (kod: ${code})`
      }
    }
  })
}

// Parse yt-dlp progress output
function parseProgress(downloadId, output) {
  const download = activeDownloads.get(downloadId)
  if (!download) return

  // Match progress patterns like: [download]  45.2% of 150.00MiB at  5.50MiB/s ETA 00:15
  const progressMatch = output.match(/\[download\]\s+([\d.]+)%\s+of\s+~?([\d.]+\w+)\s+at\s+([\d.]+\w+\/s)(?:\s+ETA\s+(\S+))?/)
  
  if (progressMatch) {
    download.progress = parseFloat(progressMatch[1])
    download.totalSize = progressMatch[2]
    download.speed = progressMatch[3]
    download.eta = progressMatch[4] || ''
    download.status = 'downloading'
  }

  // Match merging status
  if (output.includes('[Merger]') || output.includes('[ExtractAudio]') || output.includes('Merging')) {
    download.status = 'merging'
    download.progress = 99
  }

  // Match ffmpeg progress
  const ffmpegMatch = output.match(/size=\s*(\d+\w+)\s+time=(\S+)/)
  if (ffmpegMatch) {
    download.status = 'merging'
  }
}

// Get video info using yt-dlp
function getVideoInfo(url) {
  return new Promise((resolve, reject) => {
    const args = [
      '--dump-json',
      '--no-playlist',
      '--no-warnings',
      url
    ]

    const ytdlp = spawn('yt-dlp', args)
    let stdout = ''
    let stderr = ''

    ytdlp.stdout.on('data', (data) => {
      stdout += data.toString()
    })

    ytdlp.stderr.on('data', (data) => {
      stderr += data.toString()
    })

    ytdlp.on('error', (error) => {
      reject(new Error('yt-dlp bulunamadı. Lütfen yt-dlp yükleyin: https://github.com/yt-dlp/yt-dlp'))
    })

    ytdlp.on('close', (code) => {
      if (code !== 0) {
        reject(new Error(stderr || 'Video bilgisi alınamadı'))
        return
      }

      try {
        const info = JSON.parse(stdout)
        
        // Filter and format the formats
        const formats = extractFormats(info.formats || [])
        
        resolve({
          id: info.id,
          title: info.title,
          thumbnail: info.thumbnail,
          channel: info.uploader || info.channel,
          subscribers: info.channel_follower_count ? formatNumber(info.channel_follower_count) : 'N/A',
          views: info.view_count || 0,
          likes: info.like_count || 0,
          duration: info.duration || 0,
          uploadDate: info.upload_date ? formatDate(info.upload_date) : 'N/A',
          description: info.description,
          formats
        })
      } catch (e) {
        reject(new Error('Video bilgisi ayrıştırılamadı'))
      }
    })
  })
}

// Extract and format available formats (only H.264 and H.265, video+audio combined)
function extractFormats(formats) {
  const validFormats = []
  const seenQualities = new Set()

  // Find best audio format for merging
  const audioFormats = formats.filter(f => 
    f.acodec !== 'none' && 
    f.vcodec === 'none' &&
    (f.ext === 'm4a' || f.acodec?.includes('mp4a') || f.acodec?.includes('aac'))
  ).sort((a, b) => (b.abr || 0) - (a.abr || 0))

  const bestAudio = audioFormats[0]
  const bestAudioId = bestAudio?.format_id || 'bestaudio[ext=m4a]'
  const bestAudioCodec = bestAudio?.acodec || 'mp4a'
  const bestAudioBitrate = bestAudio?.abr ? `${Math.round(bestAudio.abr)} kbps` : '128 kbps'

  // Filter only H.264 (avc) and H.265 (hev/hevc) video formats
  const videoFormats = formats.filter(f => {
    if (!f.vcodec || f.vcodec === 'none' || !f.height) return false
    const codec = f.vcodec.toLowerCase()
    return codec.includes('avc') || codec.includes('h264') || 
           codec.includes('hev') || codec.includes('h265') || codec.includes('hevc')
  }).sort((a, b) => (b.height || 0) - (a.height || 0))

  for (const f of videoFormats) {
    const height = f.height
    if (!height || height < 360) continue

    // Create quality label
    let quality
    if (height >= 2160) quality = '2160p (4K)'
    else if (height >= 1440) quality = '1440p (2K)'
    else if (height >= 1080) quality = '1080p (Full HD)'
    else if (height >= 720) quality = '720p (HD)'
    else if (height >= 480) quality = '480p (SD)'
    else if (height >= 360) quality = '360p'
    else continue

    // Determine codec type
    const vcodec = f.vcodec.toLowerCase()
    const isH265 = vcodec.includes('hev') || vcodec.includes('h265') || vcodec.includes('hevc')
    const codecName = isH265 ? 'H.265' : 'H.264'
    
    // Create unique key for this quality + codec combination
    const key = `${height}-${codecName}`
    
    if (seenQualities.has(key)) continue
    seenQualities.add(key)

    // Calculate file size (video + estimated audio)
    const videoSize = f.filesize || f.filesize_approx || 0
    const audioSize = bestAudio?.filesize || bestAudio?.filesize_approx || 0
    const totalSize = videoSize + audioSize

    // Create combined format ID (video+audio)
    const combinedFormatId = `${f.format_id}+${bestAudioId}`

    validFormats.push({
      id: combinedFormatId,
      videoFormatId: f.format_id,
      audioFormatId: bestAudioId,
      quality,
      format: 'MP4',
      codec: codecName,
      audioCodec: `AAC ${bestAudioBitrate}`,
      fileSize: formatFileSize(totalSize),
      bitrate: f.tbr ? `${Math.round(f.tbr)} kbps` : 'N/A',
      fps: f.fps || 30,
      height,
      combined: true // Always combined (video + audio)
    })
  }

  // Sort by height (quality) descending, then by codec (H.264 first for compatibility)
  validFormats.sort((a, b) => {
    if (b.height !== a.height) return b.height - a.height
    return a.codec === 'H.264' ? -1 : 1
  })

  // If no H.264/H.265 formats found, add fallback
  if (validFormats.length === 0) {
    validFormats.push({
      id: 'bestvideo[vcodec^=avc]+bestaudio[ext=m4a]/best',
      quality: 'En İyi Kalite (H.264)',
      format: 'MP4',
      codec: 'H.264',
      audioCodec: 'AAC',
      fileSize: 'Değişken',
      bitrate: 'N/A',
      fps: 30,
      height: 1080,
      combined: true
    })
  }

  return validFormats.slice(0, 10) // Limit to 10 formats
}

// Format codec name
function formatCodec(codec) {
  if (!codec) return 'Bilinmiyor'
  if (codec.includes('avc') || codec.includes('h264')) return 'H.264'
  if (codec.includes('hev') || codec.includes('h265')) return 'H.265'
  if (codec.includes('vp9')) return 'VP9'
  if (codec.includes('av01')) return 'AV1'
  if (codec.includes('mp4a') || codec.includes('aac')) return 'AAC'
  if (codec.includes('opus')) return 'Opus'
  return codec.split('.')[0].toUpperCase()
}

// Estimate file size based on bitrate and duration
function estimateFileSize(format) {
  if (format.tbr && format.duration) {
    return (format.tbr * 1000 / 8) * format.duration
  }
  return null
}

// Format file size
function formatFileSize(bytes) {
  if (!bytes) return 'N/A'
  if (bytes >= 1073741824) return `${(bytes / 1073741824).toFixed(1)} GB`
  if (bytes >= 1048576) return `${Math.round(bytes / 1048576)} MB`
  if (bytes >= 1024) return `${Math.round(bytes / 1024)} KB`
  return `${bytes} B`
}

// Format number (for subscribers)
function formatNumber(num) {
  if (num >= 1000000000) return `${(num / 1000000000).toFixed(1)}B`
  if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`
  if (num >= 1000) return `${(num / 1000).toFixed(1)}K`
  return num.toString()
}

// Format date from YYYYMMDD
function formatDate(dateStr) {
  if (!dateStr || dateStr.length !== 8) return dateStr
  const year = dateStr.slice(0, 4)
  const month = dateStr.slice(4, 6)
  const day = dateStr.slice(6, 8)
  const months = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 
                  'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık']
  return `${parseInt(day)} ${months[parseInt(month) - 1]} ${year}`
}

// Clean old temp files
function cleanTempFiles() {
  try {
    const files = fs.readdirSync(TEMP_DIR)
    const now = Date.now()
    for (const file of files) {
      const filePath = path.join(TEMP_DIR, file)
      const stat = fs.statSync(filePath)
      // Delete files older than 1 hour
      if (now - stat.mtimeMs > 3600000) {
        fs.unlinkSync(filePath)
        console.log(`Cleaned old temp file: ${file}`)
      }
    }
  } catch (e) {}
}

// Clean temp files every 30 minutes
setInterval(cleanTempFiles, 1800000)

// SPA fallback - serve index.html for all non-API routes
const indexPath = path.join(__dirname, '..', 'dist', 'index.html')
if (fs.existsSync(indexPath)) {
  app.get('*', (req, res) => {
    // Skip API routes
    if (req.path.startsWith('/api')) {
      return res.status(404).json({ error: 'API endpoint not found' })
    }
    res.sendFile(indexPath)
  })
  console.log('✅ SPA fallback configured')
}

app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`)
  console.log(`📺 YouTube Downloader API ready!`)
  console.log(`🌐 Mode: ${isProduction ? 'Production' : 'Development'}`)
})
